<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html title="ЗА ДИДОВ!!!">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Моя перша веб-сторінка</title>
        <link rel="stylesheet" href="/assets/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="/assets/template.css" type="text/css" />
    </head>

    <body>
        <h1 align="center">Пєрша веб-сторінка</h1>
        <div id="menu">
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="http://google.com">На гугл</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a id="menu-item2" target="_blank" href="http://htmlbook.ru/samhtml/instrumentariy">Підручник з HTML</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="https://php.net/manual/ru/langref.php">Довідник з PHP</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="http://max.andreyalek.com/page">Друга веб старінка</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="http://max.andreyalek.com/tags">Трєтя веб старінка</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="http://max.andreyalek.com/test">Четвєртя веб старінка</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="http://max.andreyalek.com/frame">Старінка frame</a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a target="_blank" href="http://max.andreyalek.com/size">Старінка size</a>
        </div>

        <div class="jumbotron">
            <hr>
            <blockquote>
            <h1 align="center" id="text">Тарас Григорович Шевченко</h1>

            </blockquote>
            <hr>
                <p id="my-a">"Учітесь, читайте,
                І чужому научайтесь,
                Й свого не цурайтесь".</p>
            <p><a class="btn btn-primary btn-lg" role="button">Біографія</a></p>
        </div>

        <input class="form-control" />
        <br/>
        <br/>
        <div class="col-xs-3">
            <a href="#" class="thumbnail">

               <img src="http://esteticamente.ru/books/18/stg.jpg">
            </a>
        </div>
        <br/>
        <br/>
        <textarea class="form-control"></textarea>
        <br/>
        <br/>
        <button>Отправить</button>
        <a target="_blank" href="http://max.andreyalek.com/page">Моя вторая веб страница</a>
        <a class="ololo">ololo1</a>
        <a>ololo2</a>
        <a class="ololo">ololo3</a>
        <a>ololo4</a>
        <a class="ololo">ololo5</a>
        <a>ololo6</a>
        <a>ololo7</a>
        <a>ololo8</a>
        <p>Some text1</p>
        <p class="ololo">Some text2</p>
        <p>Some text3</p>
        <p class="ololo">Some text4</p>
        <p>Some text5</p>

        <div class="row">
            <div class="col-md-4">.col-md-4</div>
            <div class="col-md-4 col-md-offset-4">.col-md-4 .col-md-offset-4</div>
        </div>
        <div class="row">
            <div class="col-md-3 col-md-offset-3">.col-md-3 .col-md-offset-3</div>
            <div class="col-md-3 col-md-offset-3">.col-md-3 .col-md-offset-3</div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">.col-md-6 .col-md-offset-3</div>
        </div>
    </body>
</html>
