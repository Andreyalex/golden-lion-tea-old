<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
    "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>


<body>

<div>
    <form action="/portal/login.php" method="post">
        <p>Авторизация ЁПТ!!!</p>
        Логин:<br>
        <input type="text" name="firstname">
        <br>
        Пароль:<br>
        <input type="text" name="lastname">
        <br><br>
        Мама:<br>
        <input type="text" name="Mothers">
        <br>
        Папа:<br>
        <input type="text" name="Fathers">
        <br>
        <input type="submit">

    </form>
</div>

</body>

</html>
