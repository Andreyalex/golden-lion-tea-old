<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
    "http://www.w3.org/TR/html4/strict.dtd">
<html title="ЗА ДИДОВ!!!">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Друга веб-сторінка </title>
</head>
<body>
<p><a href="http://nvarta.com"><img <img src="http://politicana.ru/wp-content/uploads/2014/10/%D0%A1%D0%B0%D0%BD%D0%BA%D1%86%D0%B8%D0%B8-%D0%B7%D0%B0%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%BB%D0%B8.jpg"
                                           width="504" height="504"  border="2" alt="lorem" ></a></p>
<h1 align="right">Заголовок страницы</h1>
<h2 align="left">Заголовок страницы</h2>
<h3 align="center">Заголовок страницы</h3>
<h4 align="justify">Заголовок страницы</h4>
<h5 align="center">Заголовок страницы</h5>
<h6 align="right">Заголовок страницы</h6>
<h1><p align="center"><b>Основной текст.</b></p></h1>

</body>
</html>

<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title>Lorem ipsum</title>
</head>
<body>
<p align="justify">Lorem ipsum dolor sit amet consectetuer cursus pede pellentesque
    vitae pretium. <br>Tristique mus at elit lobortis libero Sed vestibulum ut
    eleifend habitasse.</br><b><big><big><big><big>Quis Nam Mauris</big></big></big></big></b> adipiscing Integer ligula dictum
    sed at enim urna. Et scelerisque id et <a target="_blank" href="http://max.andreyalek.com/page">ПАДРУГА СТАРІНКА</a> nibh dui tincidunt Curabitur faucibus
    elit massa. Tincidunt et gravida Phasellus eget parturient faucibus tellus
    at justo sollicitudin. Mi nulla ut adipiscing.</p>
<!--ПТН-ПНХ-->
</body>
</html>

<html>
<head>
    <meta http-equiv="content-type"  content="text/html; charset=utf-8">
    <title>Кавычки в атрибуте alt</title>
</head>
<body>
<p><img src="images/arena.png" alt="Вид заголовка" width="400" height="101"></p>
<p><img src="images/arena.png" alt=Вид заголовка width="400" height="101"></p>
</body>
</html>



    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title>Кавычки в атрибуте alt</title>


<p><img src="images/arena.png" alt="Вид заголовка в IE" width="400" height="101"></p>
<p><img src="images/arena.png"
        alt="Вид заголовка в браузере IE"
        width="400"
        height="101"></p>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Добавление формы</title>
</head>
<body>
<form action="self.php">
    <p><input type="text"></p>
    <p><input type="submit" disabled></p>
</form>
</body>
</html>