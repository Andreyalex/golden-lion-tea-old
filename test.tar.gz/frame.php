<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
    "http://www.w3.org/TR/html4/strict.dtd">
<html title="ЗА ДИДОВ!!!">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Тег FRAME</title>
</head>
<frameset rows="30%,30%,*" cols="30%, 30%">
    <frame src="http://max.andreyalek.com/index" name="Фрейм 1">
    <frame src="http://max.andreyalek.com/page" name="Фрейм 2">
    <frame src="http://max.andreyalek.com/tags" name="Фрейм 3">
    <frame src="http://max.andreyalek.com/test" name="Фрейм 4">
    <frame src="http://max.andreyalek.com/frame" name="Фрейм 5">
</frameset>
</html>