<!DOCTYPE HTML>
<html title="ЗА ДИДОВ!!!">
<head>
    <meta charset="utf-8">
    <title>НАІПАЛОВО ТОТАЛЬНЄ!!!</title>
</head>
<style>body {
        font-family: Arial, sans-serif; /* Рубленый шрифт */
    }
    .letter {
        color: red; /* Красный цвет символов */
        font-size: 300%; /* Размер шрифта в процентах */
        font-family: serif; /* Шрифт с засечками */
        position: relative; /* Относительное позиционирование */
        top: 5px; /* Сдвиг сверху */
    }
    del {
        color: yellowgreen; /* Цвет удаленного текста */
    }
    ins {
        color: orangered;
    }
dl {
    font-style: italic;
}
    </style>
<body>

<p align="center"><i><b><big><big><big><big><ins>ГРЕЧКУ ДАЛ??? ПИЗДЫ ПОЛУЧИЛ!!!</ins></big></big></big></big></i></b></p>
<p><b><em><p>"<span class="letter">Х</span>уле тут так мало??? Урод блин ты!!!</b>"</em> - <b>так ТИ повинен казати депутату який преніс тобі гречку</b> ipsum dolor sit amet, consectetuer
    adipiscing elit, sed diem nonummy nibh euismod tincidunt ut lacreet dolore magna
    aliguam erat volutpat.<del>Дидываиавле бляд!!!</del> <em>Ut</em> wisis enim ad minim veniam, quis
    nostrud exerci tution ullamcorper suscipit <b><i><ins>Как уебу сука!!!</ins></i></b> ut aliquip ex ea commodo
    consequat.</p>
<dl>
   <b> <dt>Наша Варта:</dt>
    <dd>Це спільнота людей, яким не байдужа доля країни.

        <br>Ми – партизани, які ведуть боротьбу на фронті інформаційної війни.</br>

        Долучайся! Разом ми – сила!</dd></b>
</dl>

<p><a href="http://nvarta.com"><img <img src="http://nvarta.com/wp-content/uploads/2014/10/6.png"
                             width="504" height="504"  border="10" alt="lorem" ></a></p>
<p><a target="_blank" href="http://nvarta.com"><b><big>НАІПАЛОВО ТОТАЛЬНЄ!!!</big></b></a></p>

<p><a href="http://nvarta.com"><img src="http://nvarta.com/wp-content/uploads/2014/10/5.png"
                             width="504" height="504"  border="10" alt="lorem" </a></p>
<p><a target="_blank" href="http://nvarta.com"><b><big>НАІПАЛОВО ТОТАЛЬНЄ!!!</big></b></a></p>

<p><a href="http://nvarta.com"><img src="http://nvarta.com/wp-content/uploads/2014/10/7.png"
                             width="504" height="504"  border="10" alt="lorem"></a></p>
<p><a target="_blank" href="http://nvarta.com"><b><big>НАІПАЛОВО ТОТАЛЬНЄ!!!</big></b></a></p>

<p><a href="http://nvarta.com"><img src="http://nvarta.com/wp-content/uploads/2014/10/3.png"
                             width="504" height="504"  border="10" alt="lorem"></a></p>
<p><a target="_blank" href="http://nvarta.com"><b><big>НАІПАЛОВО ТОТАЛЬНЄ!!!</big></b></a></p>

<p align="right" <a target="_blank" href="http://nvarta.com"><b><big>ДИ НАХУЙ ПИДР БЛЯТЬ!!!</big></b></a></p>
<iframe align="right" width="640" height="390" src="//www.youtube.com/embed/rgrpykwRHig" frameborder="0" allowfullscreen></iframe>

</body>
</html>